const Support = () => {
	return (
		<center>
			<div className="text-5xl justify-center items-center font-extrabold">
				Comming Soon
			</div>
		</center>
	);
};

export default Support;
