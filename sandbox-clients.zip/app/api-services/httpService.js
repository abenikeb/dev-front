/** @format */

import axios from "axios";

function setJwt(jwt) {
	axios.defaults.headers.common["Authorization"] = 'Bearer ' + jwt;
}

export default {
	get: axios.get,
	post: axios.post,
	put: axios.put,
	patch: axios.patch,
	delete: axios.delete,
	setJwt,
};

// axios.interceptors.response.use(null, (error) => {
// 	const ExpectedError =
// 		error.response &&
// 		error.response.status >= 400 &&
// 		error.response.status <= 500;
// 	if (!ExpectedError) {
// 		console.log('Unexpected Error', error);
// 	}

// 	return Promise.reject(error); //pass control to catch
// });


