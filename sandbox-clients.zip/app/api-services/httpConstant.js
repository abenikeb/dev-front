// export const API_END_POINT = "http://localhost:8000/api"
export const API_END_POINT = "https://developer.ethiotelecom.et/v2"