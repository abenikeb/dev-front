import React, { useState } from "react";
import Cookies from "js-cookie";
import Button from "./UI/Button/Button";
import CompleteRegistrationForm from "./CompleteRegistration";
import { useEffect } from "react";
import { getUserData } from "@app/api-services/authService";
import {
  registerOnManagementConsole,
  checkUserStatus,
} from "../app/api-services/userService";
import userSession from "@lib/hooks/userSession";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
const RegisterModal = (props) => {
  // const [isOpen, setIsOpen] = useState(true);
  const session = userSession();
  const [userId, setUserId] = useState(null);
  const [user, setUser] = useState();
  useEffect(() => {
    props.showPopup && document.getElementById("register_modal").showModal();
    setUserId(props.user_id);
  }, [props.user_id]);
  useEffect(() => {
    setUserData((prevUserData) => ({
      ...prevUserData,
      user_id: userId,
    }));
  }, [userId]);

  console.log("user id from register modal middle", userId);

  const [userData, setUserData] = useState({
    user_id: userId,
    developerTeamName: "",
    companyName: "",
    businessCategory: "",
    officialWebsite: "",
    contactPersonName: "",
    contactPhone: "",
    contactEmail: "",
  });
  // console.log(userData);
  const handleInputChange = ({ currentTarget: input }) => {
    setUserData({ ...userData, [input.name]: input.value });
    //setError(null);
  };

  // const handleSubmit = (event) => {
  //   event.preventDefault();
  //   // Complete registration and send data to API
  //   console.log(event);
  //   console.log("Name:", userData.companyName);
  //   console.log("user_id:", userData.user_id);
  //   closeModal();
  // };

  const closeModal = () => {
    console.log("closeModal triggered");
    props.onCloseModal();
  };
  // Form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const {
        user_id,
        developerTeamName,
        companyName,
        businessCategory,
        officialWebsite,
        contactPersonName,
        contactPhone,
        contactEmail,
      } = userData;
      const response = await registerOnManagementConsole(
        user_id,
        developerTeamName,
        companyName,
        businessCategory,
        officialWebsite,
        contactPersonName,
        contactPhone,
        contactEmail
      );
      console.log(userData.user_id);
      if (response.status === 201) {
        //   // const response = await checkUserStatus(user_id);
        //   const ur = Cookies.get(details);
        console.log("Submitted");
        closeModal();

        props.successMessage();

        // }
        //     setIsSubmitting(false);
        //     setErrors(null);
        //   }, 2000);
      }
      //  else if (response?.status === 400) {
      //   console.log(response.message);
      // }
    } catch (ex) {
      if (ex.response?.status === 400) {
        console.log("EXCEPTION 400", ex);
        console.log(ex.response);
        // alert(ex.response.data.error_msg);
        if (ex.response.data.error_code === "SYS0001") {
          alert(ex.response.data.error_msg);
        } else if (ex.response.data.error_code === "SYS0002") {
          alert(ex.response.data.error_msg);
        } else if (ex.response.data.error_code === "SYS0003") {
          alert(ex.response.data.error_msg);
        } else {
          alert(ex.response.data.message);
        }
        // setError(ex?.response?.data);
      } else {
        console.log("Something went wrong.");
        //setError("Something went wrong.");
      }
    } finally {
      //setErrors(null);
      // recaptchaRef.current.reset();
    }
  };
  return (
    <>
      <ToastContainer />
      {props.showPopup && (
        <dialog id="register_modal" className="modal">
          <div className="modal-box w-11/12 max-w-5xl">
            <h3 className="font-bold text-xl">Fill  Developer Information</h3>
            <CompleteRegistrationForm
              data={userData}
              setData={setUserData}
              handleSubmit={handleSubmit}
              onChange={handleInputChange}
              closeModal={closeModal}
            />
            {/* <div className="modal-action">
              <button className="btn btn-xs" onClick={closeModal}>
                Skip
              </button>
            </div> */}
          </div>
        </dialog>
      )}
    </>
  );
};

export default RegisterModal;
