import React from "react";

const CompleteRegistrationForm = ({
  data,
  setData,
  handleSubmit,
  onChange,
  closeModal
}) => {
  return (
    <>
      <form onSubmit={handleSubmit}>
        <div className="flex flex-col w-full lg:flex-row">
          {/* Left content */}
          <div className="grid flex-grow h-full place-items-left">
            <div>
              <div className="py-2">
                Developer Team Name
                <input
                  type="text"
                  name="developerTeamName"
                  value={data.developerTeamName}
                  className="input input-bordered w-full "
                  onChange={onChange}
                  placeholder="Developer Team Name"
                  required
                />
              </div>
              <div className="py-2">
                Company Name
                <input
                  type="text"
                  name="companyName"
                  value={data.companyName}
                  className="input input-bordered w-full "
                  onChange={onChange}
                  placeholder="Your Organization Name"
                  required
                />
              </div>
              <div className="py-2">
                Business Category
                <input
                  type="text"
                  name="businessCategory"
                  value={data.businessCategory}
                  className="input input-bordered w-full "
                  onChange={onChange}
                  placeholder="Company Business Category"
                  required
                />
              </div>
              <div className="py-2">
                Official Website
                <input
                  type="text"
                  name="officialWebsite"
                  value={data.officialWebsite}
                  className="input input-bordered w-full"
                  onChange={onChange}
                  placeholder="Organization website"
                  required
                />
              </div>
            </div>
          </div>
          <div className="divider lg:divider-horizontal"></div>
          {/* Right content */}
          <div className="grid flex-grow h-full place-items-left">
            <div className="py-2">
              Contact Person Name
              <input
                type="text"
                name="contactPersonName"
                value={data.contactPersonName}
                className="input input-bordered w-full "
                onChange={onChange}
                placeholder="Contact Person Full Name"
                required
              />
            </div>
            <div className="py-2">
              Contact Phone
              <input
                type="tel"
                name="contactPhone"
                value={data.contactPhone}
                className="input input-bordered w-full"
                onChange={onChange}
                placeholder="Contact Person's Number"
                required
              />
            </div>
            <div className="py-2">
              Contact E-Mail
              <input
                type="email"
                name="contactEmail"
                value={data.contactEmail}
                className="input input-bordered w-full "
                onChange={onChange}
                placeholder="Contact Person's Email"
                required
              />
            </div>
          </div>
        </div>
        <div className="flex justify-end items-end space-x-4">

        <button className="btn btn-primary border-none hover:bg-lime-400 w-32 bg-lime-500 text-white" type="submit">
          SUBMIT
        </button>
        
        <button className="btn btn-primary border-none hover:bg-gray-400 w-32 bg-gray-500 text-white" onClick={closeModal}>
                Skip
            </button>
        </div>
      </form>
    </>
  );
};

export default CompleteRegistrationForm;
