/** @format */

import Image from "next/image";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { getUserData } from "@app/api-services/authService";
import { checkUserStatus } from "@app/api-services/userService";
import Modal from "@components/Modal";
import RegisterModal from "@components/RegisterModal";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
const ApiCard = (props) => {
  const router = useRouter();
  const [incompletePopup, setIncompletePopup] = useState(false);
  const [modalPopup, setModalPopup] = useState(false);
  const [completeStatus, setCompleteStatus] = useState();
  const complete = completeStatus;
  const [userId, setUserId] = useState();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const checkMerchantStatus = async (user_id) => {
    try {
      const response = await checkUserStatus(user_id);
      const status = response.data.status;
      setCompleteStatus(status);
      console.log("complete status " + status);
    } catch (ex) {
      if (ex.response?.status === 400) {
        console.log("EX", ex);
      } else {
        console.log("something went wrong", ex);
      }
    } finally {
    }
  };
  function atStartUp() {
    const userInfo = getUserData();
    setUser(userInfo);
    const user_id = userInfo?.id;
    setUserId(user_id);
  }

  useEffect(() => {
    atStartUp();
  }, []);
  useEffect(() => {
    if (userId) {
      checkMerchantStatus(userId);
    }
  }, [userId, completeStatus]);
  const handleRouting = () => {
    console.log("run clicked");
    console.log(completeStatus);
    if (completeStatus === "completed") {
      setIncompletePopup(false);
      setModalPopup(false);
      setLoading(true);
      console.log("completed");
      router.push("/user/dashboard");
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    } else if (completeStatus === "pending") {
      setModalPopup(true);
    } else if (completeStatus === undefined) {
      checkMerchantStatus;
      setIncompletePopup(true);
    }
  };
  const showSuccessToast = () => {
    toast.success("Company Registered Successfuly. Please wait for Approval.");
  };
  const handleCloseIncompleteModal = () => {
    setIncompletePopup(false);
  };
  const handleCloseModal = () => {
    setModalPopup(false);
    // console.log("close initiatied");
  };
  return (
    <>
      <div className="bg-white md:border-solid md:border-2 md:rounded-sms mx-3 md:my-3 w-auto md:w-1/6 drop-shadow-lg my-1">
        <div className="flex md:flex-col p-5 items-center">
          <a href="/user/dashboard">
            <Image
              src={props.logo}
              // src="/assets/images/create-order.svg"
              alt="logo"
              width={150}
              height={150}
              className="w-10 md:w-max self-start mt-2 md:mt-0 md:self-center"
            />
          </a>
          <div className="flex self-start mx-2 md:mx-0 md:self-center md:items-center flex-col ml-3 md:ml-0 md:border-none w-auto">
            <p className="card__title">
              <a href="/user/dashboard">{props.title}</a>
            </p>
            <p className="card__description">
              <a href="/user/dashboard">{props.description}</a>
            </p>
          </div>
          {/* <a href="/user/dashboard" className='card_button'>Run</a> */}
          <button
            className="card__button hidden md:flex"
            onClick={handleRouting}
          >
            Run
          </button>
        </div>
      </div>
      {incompletePopup === true ? (
        <RegisterModal
          user_id={userId}
          showPopup={incompletePopup}
          successMessage={showSuccessToast}
          onCloseModal={handleCloseIncompleteModal}
        />
      ) : (
        ""
      )}
      {modalPopup === true ? (
        <Modal
          tshowPopup={modalPopup}
          onCloseModel={handleCloseModal}
          title="Pending"
          description="Your request has been submitted. Please wait for approval."
        />
      ) : (
        ""
      )}
    </>
  );
};

export default ApiCard;
